interface Num {
    num1: number;
    num2: number;
    

}

const add = function (num: Num) { 
    
    console.log("welcome to the calculator app");
    console.log("please do the opertaion what you want");
    console.log("Add (+)");
    console.log("Sub (-)");
    console.log("Mul (*)");
    console.log("Div (/)");
    return console.log(num.num1 + num.num2);
    return console.log(num.num1 - num.num2); 
    return console.log(num.num1 * num.num2); 
    return console.log(num.num1 / num.num2);

};




add({num1: 10, num2: 2});
const sub = function (num: Num) { 
    
    
    return console.log(num.num1 - num.num2);
    

};




sub({num1: 10, num2: 2});
const mul = function (num: Num) { 
    
    
    return console.log(num.num1 * num.num2);
    

};




mul({num1: 10, num2: 2});
const div = function (num: Num) { 
    
    
    return console.log(num.num1 / num.num2);
    

};




div({num1: 10, num2: 2});



